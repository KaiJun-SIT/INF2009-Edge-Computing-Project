# Surveillance Model

This is a quantized TFLite model for surveillance detection.

## Model Details
- Input Shape: ({IMG_HEIGHT}, {IMG_WIDTH}, 3)
- Input Type: uint8
- Output: {NUM_CLASSES} classes
- Base Model: ResNet50

## Usage on Raspberry Pi
1. Install TensorFlow Lite Runtime
2. Load model using:
   ```python
   import tflite_runtime.interpreter as tflite
   interpreter = tflite.Interpreter(model_path='model.tflite')
   interpreter.allocate_tensors()
   ```

## Classes
{CLASS_LABELS}
